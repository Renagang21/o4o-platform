<?php return array('dependencies' => array('jquery'), 'version' => '63cbedc2be2a37c346f6');
