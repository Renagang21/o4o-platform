<?php return array('dependencies' => array('jquery', 'wp-polyfill'), 'version' => '1c8de2d32e22494d0178');
