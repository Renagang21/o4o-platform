<?php return array('dependencies' => array('jquery', 'wc-blocks-checkout', 'wp-components', 'wp-compose', 'wp-data', 'wp-element', 'wp-hooks', 'wp-i18n'), 'version' => 'f9309c14b2766dc965ef');
