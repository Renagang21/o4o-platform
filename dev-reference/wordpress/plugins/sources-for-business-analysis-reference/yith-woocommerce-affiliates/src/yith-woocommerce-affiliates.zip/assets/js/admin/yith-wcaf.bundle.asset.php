<?php return array('dependencies' => array('jquery'), 'version' => '604c953d77cbe5125844');
