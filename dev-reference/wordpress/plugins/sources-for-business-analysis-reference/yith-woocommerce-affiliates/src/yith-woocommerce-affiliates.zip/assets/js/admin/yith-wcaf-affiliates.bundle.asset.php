<?php return array('dependencies' => array('jquery', 'wp-polyfill'), 'version' => '3819f42cecf906bfcd18');
