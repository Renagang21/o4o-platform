<?php return array('dependencies' => array('jquery', 'wp-polyfill'), 'version' => '068b2691b124ad62c18d');
