<?php return array('dependencies' => array('jquery'), 'version' => '2cd686ecbd5a305d108f');
