<?php return array('dependencies' => array('jquery'), 'version' => '13bc5ce8bab4d4cd9fa5');
