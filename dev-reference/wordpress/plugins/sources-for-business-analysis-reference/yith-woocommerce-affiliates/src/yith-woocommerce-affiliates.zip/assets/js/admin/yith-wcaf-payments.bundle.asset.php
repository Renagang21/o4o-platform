<?php return array('dependencies' => array('jquery'), 'version' => '53135a6c62cdd50c4e5b');
