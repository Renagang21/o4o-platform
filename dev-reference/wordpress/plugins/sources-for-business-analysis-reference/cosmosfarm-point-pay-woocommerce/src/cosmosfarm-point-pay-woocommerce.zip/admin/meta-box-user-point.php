<?php if (!defined('ABSPATH')) exit; ?>

<h4 class="">사용 가능한 포인트: <span class="avaliable-point" data-avaliable-point="0">0</span></h4>
<label id="input-point" style="display: flex; gap: 5px;">
	<input type="text" name="apply-point" placeholder="0" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="width: 100%;">
	<button id="apply-point" type="button" class="button">포인트 사용</button>
</label>
<label id="remove-point" style="display: none;">
	<button id="remove-point" type="button" class="button">포인트 사용 취소</button>
</label>
<p class="description cosmosfarm-point-pay-wc">
	고객 선택 시 사용가능한 포인트가 표시됩니다.
</p>

<script>
	jQuery(document).ready(function() {
		// 고객 선택
		jQuery("#customer_user").change(function() {
			var user_id = jQuery(this).val();
			jQuery.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					security: '<?php echo wp_create_nonce('cosmosfarm_point_pay_wc_security'); ?>',
					action: 'cosmosfarm_point_pay_wc_get_user_point',
					user_id: user_id
				},
				success: function(response) {
					const point = response.point;
					
					if (Number(point) < 0) {
						jQuery('.avaliable-point').text('0');
					} else {
						jQuery('.avaliable-point').attr('data-avaliable-point', point);
						jQuery('.avaliable-point').text(point.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
						jQuery('input[name="apply-point"]').attr('max', point);
					}
				}
			});
		});
		
		// 포인트 사용
		jQuery('#apply-point').click(function() {
			var user_id = jQuery('#customer_user').val();
			var point = jQuery('input[name="apply-point"]').val();
			
			if (!user_id) {
				alert('<?php echo __('선택된 고객이 없습니다.', 'cosmosfarm_point_pay-theme') ?>');
				return;
			}
			
			if (!point) {
				alert('<?php echo __('포인트를 입력해주세요.', 'cosmosfarm_point_pay-theme') ?>');
				return;
			}
			
			jQuery.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					security: '<?php echo wp_create_nonce('cosmosfarm_point_pay_wc_security'); ?>',
					action: 'cosmosfarm_point_pay_wc_admin_apply_point',
					user_id: user_id,
					point: point,
					order_id: '<?php echo $post_id; ?>'
				},
				success: function(response) {
					if (response.success) {
						const avaliable_point = parseInt(jQuery('.avaliable-point').text().replace(/,/g, '')) - point;
						
						jQuery('.avaliable-point').text(avaliable_point.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
						jQuery('#input-point').hide();
						jQuery('.description.cosmosfarm-point-pay-wc').hide();
						jQuery('#remove-point').show();
					}
					
					alert(response.msg);
					
					save_line_items();
				}
			});
		});
		
		// 포인트 사용 취소
		jQuery('#remove-point').click(function() {
			jQuery.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					security: '<?php echo wp_create_nonce('cosmosfarm_point_pay_wc_security'); ?>',
					action: 'cosmosfarm_point_pay_wc_admin_remove_point',
					order_id: '<?php echo $post_id; ?>'
				},
				success: function(response) {
					if (response.success) {
						const point = jQuery('.avaliable-point').attr('data-avaliable-point');
						jQuery('.avaliable-point').text(point.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
						
						jQuery('#remove-point').hide();
						jQuery('.description.cosmosfarm-point-pay-wc').show();
						jQuery('#input-point').css('display', 'flex');
					}
					
					alert(response.msg);
					
					save_line_items();
				}
			});
		});
		
		// 항목 업데이트
		const save_line_items = () => {
			const data = {
				order_id: '<?php echo $post_id; ?>',
				items: jQuery('table.woocommerce_order_items :input[name], .wc-order-totals-items :input[name]').serialize(),
				action: 'woocommerce_save_order_items',
				security: woocommerce_admin_meta_boxes.order_item_nonce
			};
			
			jQuery('#woocommerce-order-items').block({
				message: null,
				overlayCSS: {
					background: '#fff',
					opacity: 0.6
				}
			});
			
			jQuery.ajax({
				url: ajaxurl,
				data: data,
				type: 'POST',
				success: function(response) {
					if (response.success) {
						jQuery('#woocommerce-order-items').find('.inside').empty();
						jQuery('#woocommerce-order-items').find('.inside').append(response.data.html);
						jQuery('#woocommerce-order-items').unblock();
					} else {
						jQuery('#woocommerce-order-items').unblock();
						
						window.alert(response.data.error);
					}
				},
				complete: function() {
					window.wcTracks.recordEvent('order_edit_save_line_items', {
						order_id: '<?php echo $post_id; ?>',
						status: jQuery('#order_status').val()
					});
				}
			});
		}
	});
</script>