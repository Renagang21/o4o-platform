<?php if(!defined('ABSPATH')) exit;?>
<div class="wrap">
	<div style="float:left;margin:7px 8px 0 0;width:36px;height:34px;background:url(<?php echo COSMOSFARM_POINT_PAY_WC_URL . '/images/icon-big.png'?>) left top no-repeat;"></div>
	<h1 class="wp-heading-inline">코스모스팜 포인트 결제 for 우커머스</h1>
	<a href="https://www.cosmosfarm.com/" class="page-title-action" onclick="window.open(this.href);return false;">홈페이지</a>
	<a href="https://www.cosmosfarm.com/threads" class="page-title-action" onclick="window.open(this.href);return false;">커뮤니티</a>
	<a href="https://www.cosmosfarm.com/support" class="page-title-action" onclick="window.open(this.href);return false;">고객지원</a>
	<a href="https://blog.cosmosfarm.com/" class="page-title-action" onclick="window.open(this.href);return false;">블로그</a>
	
	<hr class="wp-header-end">
	
	<form method="post" action="<?php echo admin_url('admin-post.php')?>">
		<?php wp_nonce_field('cosmosfarm-point-pay-wc-save', 'cosmosfarm-point-pay-wc-save-nonce')?>
		<input type="hidden" name="action" value="cosmosfarm_point_pay_wc_setting_save">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><label for="cosmosfarm-point-pay-wc-use-point-active">포인트 사용</label></th>
					<td>
						<select name="cosmosfarm_point_pay_wc_setting[activation_use]" id="cosmosfarm-point-pay-wc-use-point-active">
							<option value="">비활성화</option>
							<option value="1"<?php if($activation_use):?> selected<?php endif?>>활성화</option>
						</select>
						<p class="description">
							사용자가 보유한 myCred 플러그인의 포인트로 결제할 수 있습니다.
						</p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="cosmosfarm-point-pay-wc-point-conversion-rate">포인트 사용 설정</label></th>
					<td>
						<div>
							<label>
								<input type="number" name="cosmosfarm_point_pay_wc_setting[use_rate_point]" value="<?php echo $use_rate_point ? esc_attr($use_rate_point) : 1?>" required>
								포인트 사용 시
							</label>
							<label>
								<input type="number" name="cosmosfarm_point_pay_wc_setting[use_rate_won]" value="<?php echo $use_rate_won ? esc_attr($use_rate_won) : 1?>" required>
								원 할인
							</label>
						</div>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="cosmosfarm-point-pay-wc-point-point-description">포인트 사용 안내문구 설정</label></th>
					<td>
						<input type="text" id="cosmosfarm-point-pay-wc-point-point-description" name="cosmosfarm_point_pay_wc_setting[point_description]" value="<?php echo $point_description ? esc_attr($point_description) : ''?>" class="regular-text">
						<p class="description">
							포인트 입력란 아래에 표시될 문구를 입력할 수 있습니다.
						</p>
					</td>
				</tr>
			</tbody>
		</table>
		
		<hr>
		
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><label for="cosmosfarm-point-pay-wc-earn-point-active">포인트 적립</label></th>
					<td>
						<select name="cosmosfarm_point_pay_wc_setting[activation_earn]" id="cosmosfarm-point-pay-wc-earn-point-active">
							<option value="">비활성화</option>
							<option value="1"<?php if($activation_earn):?> selected<?php endif?>>활성화</option>
						</select>
						<p class="description">
							활성화시 모든 상품에 일괄 적용됩니다.
						</p>
						<p class="description">
							각각 상품의 <code>상품 편집 → 상품 데이터 → 포인트 설정</code> 에서 비활성화 또는 적립률을 변경할 수 있습니다.
						</p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="cosmosfarm-point-pay-wc-point-conversion-rate">포인트 적립 설정</label></th>
					<td>
						<div>
							<label>
								<input type="number" name="cosmosfarm_point_pay_wc_setting[earn_rate_won]" value="<?php echo $earn_rate_won ? esc_attr($earn_rate_won) : 10?>">
								원 결제 시
							</label>
							<label>
								<input type="number" name="cosmosfarm_point_pay_wc_setting[earn_rate_point]" value="<?php echo $earn_rate_point ? esc_attr($earn_rate_point) : 1?>" required>
								포인트 적립
							</label>
						</div>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="cosmosfarm-point-pay-wc-use-point-use-notice">적립 안내 메세지</label></th>
					<td>
						<select name="cosmosfarm_point_pay_wc_setting[use_notice]" id="cosmosfarm-point-pay-wc-use-notice">
							<option value="">비활성화</option>
							<option value="1"<?php if($use_notice):?> selected<?php endif?>>활성화</option>
						</select>
						<p class="description">
							결제 페이지에서 결제 시 적립될 포인트를 표시합니다.
						</p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="cosmosfarm-point-pay-wc-earn-when-use">포인트로 결제 시 포인트 적립</label></th>
					<td>
						<select name="cosmosfarm_point_pay_wc_setting[earn_when_use]" id="cosmosfarm-point-pay-wc-earn-when-use">
							<option value="">비활성화</option>
							<option value="1"<?php if($earn_when_use):?> selected<?php endif?>>활성화</option>
						</select>
						<p class="description">카드나 계좌이체 등 현금 결제가 아닌 포인트로 결제 시에도 적립되도록 할 수 있습니다.</p>
						<p class="description">필요한 경우에만 사용해 주세요.</p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="cosmosfarm-point-pay-wc-earn-when-apply-coupon">쿠폰 사용 시 포인트 적립</label></th>
					<td>
						<select name="cosmosfarm_point_pay_wc_setting[earn_when_apply_coupon]" id="cosmosfarm-point-pay-wc-earn-when-apply-coupon">
							<option value="">비활성화</option>
							<option value="1"<?php if($earn_when_apply_coupon):?> selected<?php endif?>>활성화</option>
						</select>
						<p class="description">쿠폰 사용 시에도 포인트를 적립되도록 할 수 있습니다.</p>
					</td>
				</tr>
			</tbody>
		</table>
		
		<hr>
		
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><label for="cosmosfarm-point-pay-wc-activation-earn-write-review">상품평 작성 시 포인트 적립</label></th>
					<td>
						<select name="cosmosfarm_point_pay_wc_setting[activation_earn_when_write_review]" id="cosmosfarm-point-pay-wc-activation-earn-write-review">
							<option value="">비활성화</option>
							<option value="1"<?php if($activation_earn_when_write_review):?> selected<?php endif?>>활성화</option>
						</select>
						<p class="description">
							<a href="<?php echo esc_url(add_query_arg(array('page'=>'wc-settings', 'tab'=>'products'), admin_url('admin.php')))?>#woocommerce_enable_reviews" target="__blank">상품평</a> 기능이 활성화 되어 있어야 동작합니다.
						</p>
						<p class="description">우커머스 상품에 상품평 작성 시 포인트를 적립합니다.</p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="cosmosfarm-point-pay-wc-earn-point-write-review">공통 상품평 작성 적립 포인트</label></th>
					<td>
						<input type="number" name="cosmosfarm_point_pay_wc_setting[earn_point_when_write_review]" id="cosmosfarm-point-pay-wc-earn-point-write-review" value="<?php echo esc_attr($earn_point_when_write_review)?>">
						<p class="description">상품별 적립 포인트가 입력되어 있지 않으면 위 포인트가 적립됩니다.</p>
						<p class="description">
							상품마다 개별적으로 상품평 적립 포인트를 설정하시려면 <a href="<?php echo esc_url(add_query_arg(array('post_type'=>'product'), admin_url('edit.php')))?>" target="_blank">상품</a> 편집 화면에서 가능합니다.
						</p>
					</td>
				</tr>
			</tbody>
		</table>
		
		<p class="submit">
			<input type="submit" class="button-primary" value="변경 사항 저장">
		</p>
	</form>
</div>
<div class="clear"></div>