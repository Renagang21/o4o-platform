<?php
/*
Plugin Name: 코스모스팜 포인트 결제 for 우커머스
Plugin URI: https://www.cosmosfarm.com/wpstore/product/cosmosfarm-point-pay-woocommerce
Description: 코스모스팜에서 제공하는 우커머스 포인트 결제 및 적립 플러그인입니다.
Version: 2.0
Author: 코스모스팜 - Cosmosfarm
Author URI: https://www.cosmosfarm.com/
*/

if(!defined('ABSPATH')) exit;

define('COSMOSFARM_POINT_PAY_WC_VER', '2.0');
define('COSMOSFARM_POINT_PAY_WC_DIR', dirname(__FILE__));
define('COSMOSFARM_POINT_PAY_WC_URL', plugins_url('', __FILE__));

add_action('init', function(){
	include_once 'class/Cosmosfarm_Point_Pay_WC_Controller.class.php';
	include_once 'class/Cosmosfarm_Point_Pay_WC_Point.class.php';
	
	if(defined('myCRED_VERSION')){
		new Cosmosfarm_Point_Pay_WC_Controller();
	}
});

add_action('admin_init', function(){
	include_once 'class/Cosmosfarm_Point_Pay_WC_Admin_Controller.class.php';
	
	new Cosmosfarm_Point_Pay_WC_Admin_Controller();
});

add_action('admin_notices', function(){
	$screen = get_current_screen();
	
	if(!defined('myCRED_VERSION') && $screen->id != 'update'){
		$action  = 'install-plugin';
		$plugin  = 'mycred';
		$install = wp_nonce_url(add_query_arg(array('action'=>$action, 'plugin'=>$plugin), admin_url('update.php')), $action.'_'.$plugin);
		$message = sprintf('코스모스팜 포인트 결제 사용을 위해서는 먼저 <a href="%s">myCred</a> 플러그인을 설치하고 활성화해주세요.', $install);
		
		$class = 'notice notice-error';
		printf('<div class="%1$s"><p>%2$s</p></div>', $class, $message);
	}
});