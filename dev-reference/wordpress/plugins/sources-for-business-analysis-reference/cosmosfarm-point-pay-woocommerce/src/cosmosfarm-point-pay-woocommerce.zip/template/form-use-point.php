<?php if (!defined('ABSPATH')) exit; ?>

<link href="<?php echo COSMOSFARM_POINT_PAY_WC_URL ?>/assets/form-use-point.css" rel="stylesheet" type="text/css">

<div class="cosmosfarm-point-pay-wc form-use-point-wrap">
	<h3>포인트 사용</h3>
	<div class="cosmosfarm-point-pay-wc__field-wrapper">
		<div class="form-row">
			<label for="cosmosfarm-point-pay-wc">
				내 포인트 : <span id="cosmosfarm-my-point"><?php echo number_format($used_point ? ($my_point - $used_point) : $my_point) ?></span>
			</label>
			<div class="woocommerce-input-wrapper">
				<input type="text" id="cosmosfarm-point-pay-wc" class="input-text" name="point" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" style="width: auto;<?php echo $used_point ? 'display: none;' : '' ?>" placeholder="0" onkeydown="return event.key != 'Enter';">
				
				<?php if (!$used_point): ?>
					<button type="button" id="cosmosfarm-point-pay-wc-submit" class="button" onclick="apply_point_script('apply')">포인트 사용</button>
				<?php else: ?>
					<button type="button" id="cosmosfarm-point-pay-wc-submit" class="button" onclick="apply_point_script('clear')">포인트 취소</button>
				<?php endif ?>
				
				<?php if ($point_description): ?>
					<div class="point-description">
						<?php echo $point_description ?>
					</div>
				<?php endif ?>
			</div>
		</div>
	</div>
</div>