#cosmosfarm-point-pay-woocommerce changelog

[homepage](https://www.cosmosfarm.com/wpstore/product/cosmosfarm-point-pay-woocommerce)

2.0
----------------------------------
  1. 새 주문 추가 시 사용자 포인트 입력 기능 개선
  2. cosmosfarm_point_pay_wc_product_in_order_earn_rate_point 필터 추가
  3. cosmosfarm_point_pay_wc_product_in_order_earn_rate_won 필터 추가


1.9
----------------------------------
  1. 관리자 주문 상태 변경 시 버그 수정
  2. 포인트 적용 계산 로직 수정
  3. 포인트 사용 안내문구 옵션 추가


1.8
----------------------------------
  1. 최신 우커머스 코드 적용
  2. 포인트 사용 시 alert 문구 수정
  3. 버그 수정


1.7
----------------------------------
  1. 새 주문 추가 시 사용자 포인트 입력 기능 추가
  2. cosmosfarm_point_pay_wc_product_in_order_earn_option 필터 추가
  3. 쿠폰 사용 시 포인트 적립 옵션 추가
  4. cosmosfarm_point_pay_notice_text_earn_when_apply_coupon 필터 추가
  5. 버그 수정


1.6
----------------------------------
  1. 포인트 적립 시 주문 메모 입력
  2. 포인트 사용 시 주문 메모 입력
  3. 버그 수정


1.5
----------------------------------
  1. 버그 수정


1.4
----------------------------------
  1. 상품별 포인트 사용 불가 옵션 추가
  2. 상품평 작성 시 포인트 적립 기능 추가
  3. 버그 수정


1.3
----------------------------------
  1. 버그 수정


1.2
----------------------------------
  1. 포인트 사용 시 부가세 적용 안되도록 개선


1.1
----------------------------------
  1. 포인트 적립 시 부가세 포함하도록 개선


1.0
----------------------------------

  1. cosmosfarm_point_pay_notice_text 필터 추가
  2. 제작 완료

