<?php

/**
 * Cosmosfarm_Point_Pay_WC_Admin_Controller
 * @link https://www.cosmosfarm.com/
 * @copyright Copyright 2023 Cosmosfarm. All rights reserved.
 */
class Cosmosfarm_Point_Pay_WC_Admin_Controller {
	public function __construct(){
		add_action('admin_post_cosmosfarm_point_pay_wc_setting_save', array($this, 'setting_save'), 10);
		add_action('woocommerce_process_product_meta', array($this, 'save_fields_to_simple'), 10, 2);
		add_action('woocommerce_save_product_variation', array($this, 'save_fields_to_variations'), 10);
		
		add_action('wp_ajax_cosmosfarm_point_pay_wc_apply_point', array($this, 'set_apply_point'), 10, 1);
		add_action('wp_ajax_nopriv_cosmosfarm_point_pay_wc_apply_point', array($this, 'set_apply_point'), 10, 1);
		
		add_action('wp_ajax_cosmosfarm_point_pay_wc_get_user_point', array($this, 'get_user_point'), 10, 1);
		add_action('wp_ajax_cosmosfarm_point_pay_wc_admin_apply_point', array($this, 'admin_apply_point'), 10, 1);
		add_action('wp_ajax_cosmosfarm_point_pay_wc_admin_remove_point', array($this, 'admin_remove_point'), 10, 1);
	}
	
	/**
	 * 포인트 설정을 저장한다.
	 */
	public function setting_save(){
		if(current_user_can('manage_options') && isset($_POST['cosmosfarm-point-pay-wc-save-nonce']) && wp_verify_nonce($_POST['cosmosfarm-point-pay-wc-save-nonce'], 'cosmosfarm-point-pay-wc-save')){
			$setting = isset($_POST['cosmosfarm_point_pay_wc_setting']) ? $_POST['cosmosfarm_point_pay_wc_setting'] : '';
			if($setting){
				foreach ($setting as $name => $value){
					$setting[$name] = sanitize_text_field($value);
				}
			}
			
			update_option('cosmosfarm_point_pay_wc_setting', $setting);
			wp_redirect(admin_url("admin.php?page=cosmosfarm-point-pay-wc"));
		} else {
			wp_die('권한이 없습니다.');
		}
	}
	
	/**
	 * 단순 상품의 상품별 포인트 정보를 저장한다.
	 */
	public function save_fields_to_simple($product_id, $post){
		$earn_option = isset($_POST['cosmosfarm_point_pay_wc_earn_option']) ? intval($_POST['cosmosfarm_point_pay_wc_earn_option']) : '';
		update_post_meta($product_id, 'cosmosfarm_point_pay_wc_earn_option', $earn_option);
		
		$earn_rate_point = isset($_POST['cosmosfarm_point_pay_wc_earn_rate_point']) ? sanitize_text_field($_POST['cosmosfarm_point_pay_wc_earn_rate_point']) : '';
		update_post_meta($product_id, 'cosmosfarm_point_pay_wc_earn_rate_point', $earn_rate_point);
		
		$use_option = isset($_POST['cosmosfarm_point_pay_wc_use_restrict']) ? intval($_POST['cosmosfarm_point_pay_wc_use_restrict']) : '';
		update_post_meta($product_id, 'cosmosfarm_point_pay_wc_use_restrict', $use_option);
		
		$review_point = isset($_POST['cosmosfarm_point_pay_wc_earn_point_when_write_review']) ? sanitize_text_field($_POST['cosmosfarm_point_pay_wc_earn_point_when_write_review']) : '';
		update_post_meta($product_id, 'cosmosfarm_point_pay_wc_earn_point_when_write_review', $review_point);
	}
	
	/**
	 * 옵션 상품의 상품별 포인트 정보를 저장한다.
	 */
	public function save_fields_to_variations(){
		foreach ($_POST['variable_post_id'] as $id){
			if(isset($_POST['cosmosfarm_point_pay_wc_earn_option_' . $id])){
				update_post_meta($id, 'cosmosfarm_point_pay_wc_earn_option', intval($_POST['cosmosfarm_point_pay_wc_earn_option_' . $id]));
			}
			
			if(isset($_POST['cosmosfarm_point_pay_wc_earn_rate_point_' . $id])){
				update_post_meta($id, 'cosmosfarm_point_pay_wc_earn_rate_point', sanitize_text_field($_POST['cosmosfarm_point_pay_wc_earn_rate_point_' . $id]));
			}
			
			if(isset($_POST['cosmosfarm_point_pay_wc_use_restrict_' . $id])){
				update_post_meta($id, 'cosmosfarm_point_pay_wc_use_restrict', intval($_POST['cosmosfarm_point_pay_wc_use_restrict_' . $id]));
			}
		}
	}
	
	/**
	 * 사용할 포인트를 장바구니에 저장 / 삭제 후 결과를 반환한다.
	 */
	public function set_apply_point(){
		check_ajax_referer('cosmosfarm_point_pay_wc_security', 'security');
		
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		if(!$activation_use){
			$result['msg'] = '포인트 사용이 활성화 되지 않았습니다.';
		}
		
		$my_point  = mycred_get_users_balance(get_current_user_id());
		$type      = isset($_POST['type'])  ? sanitize_text_field($_POST['type']) : '';
		$use_point = isset($_POST['point']) ? intval($_POST['point'])             : '';
		
		$result = [
			'result'              => 'error',
			'earn_when_use'       => $earn_when_use,
			'earn_when_use_alert' => ($activation_earn && !$earn_when_use) ? true : false,
		];
		
		if(!session_id()){
			session_start();
		}
		
		if($type == 'clear'){
			$cart = WC()->cart->cart_contents;
			foreach ($cart as $cart_item_id => $cart_item){
				unset($cart_item['cosmosfarm_point_pay_wc_apply_point']);
				unset($cart_item['cosmosfarm_point_pay_wc_used_point']);
				WC()->cart->cart_contents[$cart_item_id] = $cart_item;
			}
			WC()->cart->set_session();
			
			$result['result']   = 'success';
			$result['type']     = 'clear';
			$result['my_point'] = number_format($my_point);
			$result['msg']      = '';
		} else if($type == 'apply'){
			// 보유 포인트가 사용 포인트보다 크거나 같을 때만 포인트 적용
			if((int)$my_point >= (int)$use_point){
				extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
				
				$apply_point = 0;
				$cart = WC()->cart;
				
				// 포인트 사용 불가 상품이 있는 경우 계산하지 않는다.
				foreach ($cart->get_cart() as $item){
					$product_id           = isset($item['variation_id']) && $item['variation_id'] ? intval($item['variation_id']) : intval($item['product_id']);
					$product_use_restrict = get_post_meta($product_id, 'cosmosfarm_point_pay_wc_use_restrict', true);
					
					if($product_use_restrict){
						break;
					}
				}
				
				if($product_use_restrict){
					$result['msg'] = '포인트 사용이 불가능한 상품이 있습니다.';
				} else {
					// 사용한 포인트 계산
					$apply_point = (int)$use_point * ((int)$use_rate_won / (int)$use_rate_point);
					$continue = true;
					
					// 적용될 포인트가 결제금액보다 크면 결제금액으로 다시 계산
					if((int)$cart->subtotal < (int)$apply_point){
						$apply_point = $cart->subtotal;
						$use_point   = (int)$apply_point * ((int)$use_rate_point / (int)$use_rate_won);
					}
					
					if($continue){
						foreach ($cart->cart_contents as $cart_item_id => $cart_item){
							$cart_item['cosmosfarm_point_pay_wc_apply_point'] = $apply_point;
							$cart_item['cosmosfarm_point_pay_wc_used_point']  = $use_point;
							$cart->cart_contents[$cart_item_id] = $cart_item;
						}
						
						$cart->set_session();
						
						$result['result']      = 'success';
						$result['type']        = 'apply';
						$result['my_point']    = number_format($my_point - $use_point);
						$result['point']       = $use_point;
						$result['apply_point'] = $apply_point;
						$result['msg']         = '';
					}
				}
			} else {
				$result['msg'] = '포인트가 부족합니다.';
			}
		}
		
		wp_send_json($result);
	}
	
	/**
	 * 사용자 선택 시 사용자의 보유 포인트를 가져온다.
	 */
	public function get_user_point(){
		check_ajax_referer('cosmosfarm_point_pay_wc_security', 'security');
		
		$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
		if(!$user_id){
			wp_send_json([
				'success' => false,
				'msg'     => __('사용자가 없습니다.', 'cosmosfarm-point-pay-wc'),
			]);
		}
		
		$point = mycred_get_users_balance($user_id);
		wp_send_json([
			'success' => true,
			'user_id' => $user_id,
			'point'   => $point,
			'msg'     => ''
		]);
	}
	
	/**
	 * 새 주문에서 포인트를 적용한다.
	 */
	public function admin_apply_point(){
		check_ajax_referer('cosmosfarm_point_pay_wc_security', 'security');
		
		$user_id   = isset($_POST['user_id'])  ? absint($_POST['user_id'])  : 0;
		$use_point = isset($_POST['point'])    ? absint($_POST['point'])    : 0;
		$order_id  = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
		
		$balance = mycred_get_users_balance($user_id);
		if($balance < $point){
			wp_send_json([
				'success' => false,
				'msg'     => __('포인트가 부족합니다.', 'cosmosfarm-point-pay-wc')
			]);
		}
		
		$order = wc_get_order($order_id);
		$items = $order->get_items();
		foreach ($items as $item){
			$product_id           = isset($item['variation_id']) && $item['variation_id'] ? intval($item['variation_id']) : intval($item['product_id']);
			$product_use_restrict = get_post_meta($product_id, 'cosmosfarm_point_pay_wc_use_restrict', true);
			
			if($product_use_restrict){
				break;
			}
		}
		
		if($product_use_restrict){
			wp_send_json([
				'success' => false,
				'msg'     => __('포인트 사용이 제한된 상품이 있습니다.', 'cosmosfarm-point-pay-wc')
			]);
		}
		
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		$apply_point = (int)$use_point * ((int)$use_rate_won / (int)$use_rate_point);
		$continue    = true;
		
		// 적용될 포인트가 결제금액보다 크면 결제금액으로 다시 계산
		$sub_total = $order->get_subtotal();
		if((int)$sub_total < (int)$apply_point){
			$apply_point = $sub_total;
			$use_point   = (int)$apply_point * ((int)$use_rate_point / (int)$use_rate_won);
		}
		
		if($continue){
			$order->update_meta_data('cosmosfarm_point_pay_wc_apply_point', $apply_point);
			$order->update_meta_data('cosmosfarm_point_pay_wc_used_point', $use_point);
			
			// 결제 금액 변경
			$order->set_total($order->get_total() - $apply_point);
			$order->save();
		}
		
		wp_send_json(
			[
				'success' => true,
				'msg'     => __(number_format($use_point) . ' 포인트가 사용되었습니다.', 'cosmosfarm-point-pay-wc')
			]
		);
	}
	
	/**
	 * 새 주문에 적용된 포인트를 제거한다.
	 */
	public function admin_remove_point(){
		check_ajax_referer('cosmosfarm_point_pay_wc_security', 'security');
		
		$order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
		if(!$order_id){
			wp_send_json(
				[
					'error' => false,
					'msg' => __('주문 정보가 없습니다.', 'cosmosfarm-point-pay-wc')
				]
			);
		}
		
		$order = wc_get_order($order_id);
		
		$order->delete_meta_data('cosmosfarm_point_pay_wc_apply_point');
		$order->delete_meta_data('cosmosfarm_point_pay_wc_used_point');
		
		$order->set_total($order->get_total() + $apply_point);
		$order->save();
		
		wp_send_json(
			[
				'success' => true,
				'msg'     => __('포인트 사용이 취소되었습니다.', 'cosmosfarm-point-pay-wc')
			]
		);
	}
}
