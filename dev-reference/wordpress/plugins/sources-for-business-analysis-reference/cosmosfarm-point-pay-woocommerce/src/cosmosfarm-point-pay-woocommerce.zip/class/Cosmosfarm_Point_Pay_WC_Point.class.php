<?php
/**
 * Cosmosfarm_Point_Pay_WC_Point
 * @link https://www.cosmosfarm.com/
 * @copyright Copyright 2023 Cosmosfarm. All rights reserved.
 */
class Cosmosfarm_Point_Pay_WC_Point {
	
	/**
	 * 포인트 설정을 반환한다.
	 */
	public static function get_cosmosfarm_point_pay_wc_setting(){
		$array = array(
			'activation_use'         => '',
			'activation_earn'        => '',
			'earn_rate_won'          => '',
			'earn_rate_point'        => '',
			'use_rate_won'           => '',
			'use_rate_point'         => '',
			'use_notice'             => '',
			'earn_when_use'          => '',
			'earn_when_apply_coupon' => '',
			'point_description'      => '',
			
			'activation_earn_when_write_review' => '',
			'earn_point_when_write_review'      => '',
		);
		$setting = get_option('cosmosfarm_point_pay_wc_setting', array());
		$setting = array_merge($array, $setting);
		
		return $setting;
	}
	
	/**
	 * 상품별 포인트 사용 여부를 반환한다.
	 */
	public function get_earn_option($variation_id=''){
		$args = array();
		
		if($variation_id){
			$args['id']            = 'cosmosfarm_point_pay_wc_earn_option_' . $variation_id;
			$args['value']         = get_post_meta($variation_id, 'cosmosfarm_point_pay_wc_earn_option', true);
			$args['wrapper_class'] = 'form-field form-row';
		}
		else{
			$args['id']            = 'cosmosfarm_point_pay_wc_earn_option';
			$args['value']         = get_post_meta(get_the_ID(), 'cosmosfarm_point_pay_wc_earn_option', true);
			$args['wrapper_class'] = 'form-field';
		}
		
		$args['label']        = '포인트 적립';
		$args['options']['']  = '포인트 적립함';
		$args['options']['1'] = '이 상품 포인트 적립 안함';
		$args['options']['2'] = '상품별 포인트 적립 사용';
		$args['desc_tip']     = true;
		$args['description']  = '';
		
		return $args;
	}
	
	/**
	 * 상품별 포인트 전환율을 반환한다.
	 */
	public function get_earn_point($variation_id=''){
		$args        = array();
		$earn_option = get_post_meta($variation_id, 'cosmosfarm_point_pay_wc_earn_option', true);
		
		if($variation_id){
			$args['id']            = 'cosmosfarm_point_pay_wc_earn_rate_point_' . $variation_id;
			$args['value']         = get_post_meta($variation_id, 'cosmosfarm_point_pay_wc_earn_rate_point', true);
			$args['wrapper_class'] = 'form-field form-row '.($earn_option != '2' ? 'hidden' : '');
		}
		else{
			$args['id']            = 'cosmosfarm_point_pay_wc_earn_rate_point';
			$args['value']         = get_post_meta(get_the_ID(), 'cosmosfarm_point_pay_wc_earn_rate_point', true);
			$args['wrapper_class'] = 'form-field '.($earn_option != '2' ? 'hidden' : '');
		}
		$args['label']       = '1원당 전환율';
		$args['desc_tip']    = true;
		$args['description'] = '이 상품에만 적용할 1원당 적립될 포인트 전환율을 입력하세요. ex) 1 이면 100%, 0.1 이면 10% 0.01이면 1% 입니다.';
		
		return $args;
	}
	
	/**
	 * 상품별 포인트 사용 여부를 반환한다.
	 */
	public function get_use_option($variation_id=''){
		$args = array();
		
		if($variation_id){
			$args['id']            = 'cosmosfarm_point_pay_wc_use_restrict_' . $variation_id;
			$args['value']         = get_post_meta($variation_id, 'cosmosfarm_point_pay_wc_use_restrict', true);
			$args['wrapper_class'] = 'form-field form-row';
		}
		else{
			$args['id']            = 'cosmosfarm_point_pay_wc_use_restrict';
			$args['value']         = get_post_meta(get_the_ID(), 'cosmosfarm_point_pay_wc_use_restrict', true);
			$args['wrapper_class'] = 'form-field';
		}
		$args['label']         = '포인트 사용';
		$args['options']['']   = '포인트 사용 가능';
		$args['options']['1']  = '포인트 사용 불가';
		$args['desc_tip']      = true;
		$args['description']   = '포인트 사용 불가 상품이 장바구니에 있는 경우, 포인트를 사용할 수 없습니다.';
		
		return $args;
	}
	
	/**
	 * 상품별 상품평 작성 시 적립할 포인트를 반환한다.
	 */
	public function get_earn_point_when_write_review(){
		$args        = array();
		$args['id']            = 'cosmosfarm_point_pay_wc_earn_point_when_write_review';
		$args['value']         = get_post_meta(get_the_ID(), 'cosmosfarm_point_pay_wc_earn_point_when_write_review', true);
		$args['wrapper_class'] = 'form-field';
		$args['label']         = '상품평 작성 적립 포인트';
		$args['desc_tip']      = true;
		$args['description']   = '이 상품에만 적용할 상품평 작성 시 적립할 포인트 입력하세요. <br>이 상품만 포인트를 적립하지 않으려면 0을 입력하세요.';
		
		return $args;
	}
}