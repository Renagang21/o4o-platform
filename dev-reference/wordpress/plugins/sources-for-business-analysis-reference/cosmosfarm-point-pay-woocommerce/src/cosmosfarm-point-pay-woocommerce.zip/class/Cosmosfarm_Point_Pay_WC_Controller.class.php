<?php
/**
 * Cosmosfarm_Point_Pay_WC_Controller
 * @link https://www.cosmosfarm.com/
 * @copyright Copyright 2023 Cosmosfarm. All rights reserved.
 */
class Cosmosfarm_Point_Pay_WC_Controller {
	
	public function __construct(){
		add_action('admin_menu', array($this, 'admin_submenu_page'));
		add_action('woocommerce_before_checkout_form', array($this, 'notice_on_checkout'), 10);
		
		add_action('woocommerce_checkout_billing', array($this, 'show_point_table'), 5, 1);
		add_action('wp_footer', array($this, 'apply_point_script'), 10, 1);
		
		add_filter('woocommerce_calculated_total', array($this, 'caculate_point'), 10, 2);
		add_action('woocommerce_review_order_before_order_total', array($this, 'show_apply_point'), 10, 1);
		add_filter('woocommerce_checkout_create_order', array($this, 'before_order'), 10, 1);
		add_action('woocommerce_order_status_changed', array($this, 'after_order'), 10, 3);
		add_filter('woocommerce_get_order_item_totals', array($this, 'show_point_info_order_detail_in_my_account'), 10, 2);
		add_action('woocommerce_admin_order_totals_after_discount', array($this, 'show_point_info_order_detail_in_admin'), 10, 1);
		add_action('woocommerce_order_refunded', array($this, 'withdraw_point_after_order_refunded'), 10, 2);
		
		add_action('save_post', array($this, 'calculate_point_when_save_order'), 999, 1);
		add_action('woocommerce_order_after_calculate_totals', array($this, 'calculate_totals_when_recalculate'), 999,2);
		
		add_filter('woocommerce_product_data_tabs', array($this, 'create_point_tabs'), 10, 1);
		add_action('woocommerce_product_data_panels', array($this, 'get_fields_to_simple'), 10, 1);
		add_action('woocommerce_product_after_variable_attributes', array($this, 'get_fields_to_variations'), 10, 3);
		add_filter('woocommerce_product_data_tabs', array($this, 'create_review_point_tabs'), 10, 1);
		add_action('woocommerce_product_data_panels', array($this, 'get_fields_to_review_point'), 10, 1);
		
		add_action('wp_insert_comment', array($this, 'earn_write_review'), 99, 2);
		
		add_action('add_meta_boxes', array($this, 'add_meta_box'), 5, 2);
	}
	
	/**
	 * 우커머스 메뉴에 추가한다.
	 */
	public function admin_submenu_page(){
		add_submenu_page('woocommerce', '포인트 설정', '포인트 설정', 'manage_options', 'cosmosfarm-point-pay-wc', array($this, 'cosmosfarm_point_pay_wc'), 10);
		// add_submenu_page('woocommerce', '포인트 로그', '포인트 로그', 'manage_options', 'cosmosfarm-point-pay-wc-log', array($this, 'cosmosfarm_point_pay_wc_log'), 10);
	}
	
	public function cosmosfarm_point_pay_wc(){
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		include_once COSMOSFARM_POINT_PAY_WC_DIR . '/admin/setting.php';
	}
	
	public function cosmosfarm_point_pay_wc_log(){
		include_once COSMOSFARM_POINT_PAY_WC_DIR . '/admin/point-log.php';
	}
	
	/**
	 * 결제페이지에 적립 알림을 표시한다.
	 */
	public function notice_on_checkout(){
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		if($activation_earn && $use_notice && $earn_rate_won && $earn_rate_point){
			if(!$earn_when_apply_coupon){
				$coupon = WC()->cart->get_coupons();
				
				if($coupon){
					$notice_text = apply_filters('cosmosfarm_point_pay_notice_text_earn_when_apply_coupon', '쿠폰 사용 시 포인트 적립이 되지 않습니다.');
					wc_print_notice($notice_text, 'notice');
					return;
				}
			}
			
			$user_id = get_current_user_id();
			
			$earn_point = 0;
			foreach(WC()->cart->get_cart() as $item){
				$product_id          = isset($item['variation_id']) && $item['variation_id'] ? intval($item['variation_id']) : intval($item['product_id']);
				
				$item_tax            = isset($item['line_tax'])   ? intval($item['line_tax'])   : 0;
				$item_total          = isset($item['line_total']) ? intval($item['line_total']) : 0;
				
				$product_earn_option = get_post_meta($product_id, 'cosmosfarm_point_pay_wc_earn_option', true);
				
				// 0: 적립, 1: 상품 적립 안함, 2: 상품별 포인트 적립 사용
				if($product_earn_option == '1'){
					continue;
				}
				else if($product_earn_option == '2'){
					$product_earn_rate_point = get_post_meta($product_id, 'cosmosfarm_point_pay_wc_earn_rate_point', true);
					$product_earn_rate_point = apply_filters('cosmosfarm_point_pay_wc_product_in_order_earn_rate_point', $product_earn_rate_point, $item, $user_id);
					
					$earn_point += ((int)$item_total + (int)$item_tax) * (float)$product_earn_rate_point;
				}
				else{
					$earn_rate_won   = apply_filters('cosmosfarm_point_pay_wc_product_in_order_earn_rate_won', $earn_rate_won, $item, $user_id);
					$earn_rate_point = apply_filters('cosmosfarm_point_pay_wc_product_in_order_earn_rate_point', $earn_rate_point, $item, $user_id);
					
					$earn_point += round(((int)$item_total + (int)$item_tax) * ((float)$earn_rate_point / (float)$earn_rate_won));
				}
			}
			
			if($earn_point){
				$notice_text = apply_filters('cosmosfarm_point_pay_notice_text', '결제 완료 시 <strong>%s 포인트</strong>가 적립됩니다.');
				wc_print_notice(
					sprintf($notice_text, number_format($earn_point)),
					'notice'
				);
			}
		}
	}
	
	/**
	 * 포인트 입력 필드를 표시한다.
	 */
	public function show_point_table(){
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		if(!$activation_use){
			return;
		}
		
		if(!is_user_logged_in()){
			return;
		}
		
		$my_point = mycred_get_users_balance(get_current_user_id());
		$cart     = WC()->cart->get_cart();
		
		// 포인트 사용 불가 상품이 있는 경우 필드를 표시하지 않는다.
		foreach($cart as $item){
			$product_id           = isset($item['variation_id']) && $item['variation_id'] ? intval($item['variation_id']) : intval($item['product_id']);
			$product_use_restrict = get_post_meta($product_id, 'cosmosfarm_point_pay_wc_use_restrict', true);
			if($product_use_restrict){
				return;
			}
		}
		
		$cart_data  = current($cart);
		$used_point = isset($cart_data['cosmosfarm_point_pay_wc_used_point']) ? intval($cart_data['cosmosfarm_point_pay_wc_used_point']) : '';
		
		ob_start();
		
		include COSMOSFARM_POINT_PAY_WC_DIR . '/template/form-use-point.php';
		
		echo ob_get_clean();
	}
	
	/**
	 * 포인트 사용 스크립트를 입력한다.
	 */
	public function apply_point_script(){
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		if(!$activation_use){
			return;
		}
		
		if(!is_checkout()){
			return;
		}
		
		ob_start();
		?>
		<script>
		function apply_point_script(type){
			var point    = jQuery("#cosmosfarm-point-pay-wc").val();
			var ajaxurl  = "<?php echo admin_url('admin-ajax.php')?>";
			var security = "<?php echo wp_create_nonce("cosmosfarm_point_pay_wc_security")?>";
			
			var data = {
				"action"   : "cosmosfarm_point_pay_wc_apply_point",
				"point"    : point,
				"type"     : type,
				"security" : security,
			};
			
			if(!point && type == 'apply'){
				alert('포인트를 입력해주세요.');
				return;
			}
			
			jQuery.post(ajaxurl, data, function(res){
				if(res){
					if(res.result == 'error'){
						alert(res.msg);
						return false;
					}
					
					if(res.type == 'apply'){
						jQuery("#cosmosfarm-my-point").text(res.my_point);
						jQuery("#cosmosfarm-point-pay-wc").val('');
						jQuery("#cosmosfarm-point-pay-wc").hide();
						jQuery("#cosmosfarm-point-pay-wc-submit").attr("onclick", "apply_point_script('clear')");
						jQuery("#cosmosfarm-point-pay-wc-submit").text('포인트 취소');
						
						if(res.earn_when_use_alert){
							alert('포인트를 사용하는 경우에는 포인트 적립이 되지 않습니다.');
						}
					}
					else{
						jQuery("#cosmosfarm-my-point").text(res.my_point);
						jQuery("#cosmosfarm-point-pay-wc").val('');
						jQuery("#cosmosfarm-point-pay-wc").show();
						jQuery("#cosmosfarm-point-pay-wc-submit").attr("onclick", "apply_point_script('apply')");
						jQuery("#cosmosfarm-point-pay-wc-submit").text('포인트 사용');
					}
					
					jQuery("body").trigger("update_checkout");
				}
			});
		}
		</script>
		<?php
		echo ob_get_clean();
	}
	
	/**
	 * 포인트 표시 및 금액을 계산한다.
	 */
	public function caculate_point($total, $cart){
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		if(!$activation_use){
			return $total;
		}
		
		foreach($cart->get_cart() as $item){
			$point = isset($item['cosmosfarm_point_pay_wc_apply_point']) ? intval($item['cosmosfarm_point_pay_wc_apply_point']) : '';
			
			// 포인트 사용 불가 상품이 있는 경우 계산하지 않는다.
			$product_id           = isset($item['variation_id']) && $item['variation_id'] ? intval($item['variation_id']) : intval($item['product_id']);
			$product_use_restrict = get_post_meta($product_id, 'cosmosfarm_point_pay_wc_use_restrict', true);
			if($product_use_restrict){
				return $total;
			}
		}
		
		if($point){
			$total -= $point;
		}
		
		return $total;
	}
	
	public function show_apply_point(){
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		if(!$activation_use){
			return;
		}
		
		foreach(WC()->cart->get_cart() as $item){
			$point = isset($item['cosmosfarm_point_pay_wc_apply_point']) ? intval($item['cosmosfarm_point_pay_wc_apply_point']) : '';
			
			// 포인트 사용 불가 상품이 있는 경우 표시하지 않는다.
			$product_id           = isset($item['variation_id']) && $item['variation_id'] ? intval($item['variation_id']) : intval($item['product_id']);
			$product_use_restrict = get_post_meta($product_id, 'cosmosfarm_point_pay_wc_use_restrict', true);
			
			if($product_use_restrict){
				return;
			}
		}
		
		if($point):
		ob_start()
		?>
		<tr class="order-point">
			<th>포인트 사용</th>
			<td>-<?php echo wc_price($point)?></td>
		</tr>
		<?php
		echo ob_get_clean();
		endif;
	}
	
	/**
	 * 주문 완료 전 포인트를 주문 정보에 포인트를 저장한다.
	 */
	public function before_order($order){
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		if(!$activation_use){
			return $order;
		}
		
		$cart        = WC()->cart->get_cart();
		$cart_data   = current($cart);
		$apply_point = isset($cart_data['cosmosfarm_point_pay_wc_apply_point']) ? intval($cart_data['cosmosfarm_point_pay_wc_apply_point']) : '';
		$used_point  = isset($cart_data['cosmosfarm_point_pay_wc_used_point'])  ? intval($cart_data['cosmosfarm_point_pay_wc_used_point'])  : '';
		
		$order->update_meta_data('cosmosfarm_point_pay_wc_apply_point', $apply_point);
		$order->update_meta_data('cosmosfarm_point_pay_wc_used_point', $used_point);
		$order->save();
		
		return $order;
	}
	
	/**
	 * 주문 완료 후 포인트 적립, 사용을 메타 데이터에 저장한다.
	 */
	public function after_order($order_id, $old_status, $new_status){
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		// 포인트 사용 활성화 확인
		if(!$activation_use){
			return;
		}
		
		$order       = wc_get_order($order_id);
		$apply_point = $order->get_meta('cosmosfarm_point_pay_wc_apply_point', true);
		$used_point  = $order->get_meta('cosmosfarm_point_pay_wc_used_point', true);
		$user_id     = $order->get_customer_id();
		
		$is_applied_point      = $order->get_meta('cosmosfarm_point_pay_wc_is_applied_point', true);
		$prev_is_applied_point = $order->get_meta('cosmosfarm_pay_is_applied_point', true);
		if($prev_is_applied_point){
			$prev_is_applied_point = $prev_is_applied_point;
		}
		
		
		// 사용한 포인트 정보 저장
		if($apply_point){
			// 포인트 중복 사용 방지
			if(!$is_applied_point && $used_point){
				mycred_add('pay_point', $user_id, '-'.$used_point, "주문번호 '{$order_id}'번 주문, '".number_format($used_point)."' 포인트 사용");
				$order->update_meta_data('cosmosfarm_point_pay_wc_is_applied_point', '1');
				
				if($prev_is_applied_point){
					$order->update_meta_data('cosmosfarm_pay_is_applied_point', '1');
				}
				
				$order->add_order_note(number_format($used_point).' 포인트가 사용되었습니다.');
				
				$order->save();
			}
			
			// 포인트 사용 시 포인트 적립 확인
			if(!$earn_when_use){
				return;
			}
		}
		
		// 주문 상태 완료 시
		if($new_status != 'completed'){
			return;
		}
		
		// 포인트 적립 활성화 확인
		if(!$activation_earn){
			return;
		}
		
		// 쿠폰 사용 시 포인트 적립 방지 확인
		if(!$earn_when_apply_coupon){
			$coupons = $order->get_coupon_codes();
			if(!empty($coupons)){
				return;
			}
		}
		
		// 포인트 중복 적립 방지
		$is_earned_point = $order->get_meta('cosmosfarm_point_pay_wc_earn_point', true);
		
		if($is_earned_point){
			return;
		}
		
		// 적립할 포인트 정보 저장 및 포인트 적립
		$earn_point = 0;
		$item_total = 0;
		foreach($order->get_items() as $item){
			$product_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();
			
			$product_earn_option     = get_post_meta($product_id, 'cosmosfarm_point_pay_wc_earn_option', true);
			$product_earn_rate_point = get_post_meta($product_id, 'cosmosfarm_point_pay_wc_earn_rate_point', true);
			$item_tax                = isset($item['line_tax'])   ? intval($item['line_tax'])   : 0;
			$item_total              = isset($item['line_total']) ? intval($item['line_total']) : 0;
			
			$product_earn_option = apply_filters('cosmosfarm_point_pay_wc_product_in_order_earn_option', $product_earn_option, $item, $user_id);
			
			// 0: 적립, 1: 상품 적립 안함, 2: 상품별 포인트 적립 사용
			if($product_earn_option == '1'){
				continue;
			}
			else if($product_earn_option == '2'){
				$product_earn_rate_point = apply_filters('cosmosfarm_point_pay_wc_product_in_order_earn_rate_point', $product_earn_rate_point, $item, $user_id);
				
				$earn_point += ((int)$item_total + (int)$item_tax) * (float)$product_earn_rate_point;
			}
			else{
				$earn_rate_won   = apply_filters('cosmosfarm_point_pay_wc_product_in_order_earn_rate_won', $earn_rate_won, $item, $user_id);
				$earn_rate_point = apply_filters('cosmosfarm_point_pay_wc_product_in_order_earn_rate_point', $earn_rate_point, $item, $user_id);
				
				$earn_point += round(((int)$item_total + (int)$item_tax) * ((float)$earn_rate_point / (float)$earn_rate_won));
			}
		}
		
		if($earn_point){
			mycred_add('pay_point', $user_id, $earn_point, "주문번호 '{$order_id}'번 주문, '".number_format($earn_point)."' 포인트 적립");
			$order->update_meta_data('cosmosfarm_point_pay_wc_earn_point', $earn_point);
			$order->add_order_note(number_format($earn_point).' 포인트가 적립되었습니다.');
			
			$order->save();
		}
	}
	
	/**
	 * 고객 주문 상세 페이지에 사용한 포인트를 표시한다.
	 */
	public function show_point_info_order_detail_in_my_account($total_rows, $order){
		$point = $order->get_meta('cosmosfarm_point_pay_wc_apply_point', true);
		
		if($point){
			$array_apply_point = array('apply_point' => array(
				'label' => '포인트 사용',
				'value' => '-'.wc_price($point),
			));
			
			if(isset($total_rows['shipping'])){
				$offset = array_search('shipping', array_keys($total_rows), true);
				array_splice($total_rows, $offset, 0, $array_apply_point);
			}
			else{
				if(isset($total_rows['order_total'])){
					$offset = array_search('order_total', array_keys($total_rows), true);
					array_splice($total_rows, $offset, 0, $array_apply_point);
				}
			}
		}
		
		return $total_rows;
	}
	
	/**
	 * 관리자 주문 수정 페이지에 사용한 포인트를 표시한다.
	 */
	public function show_point_info_order_detail_in_admin($order_id){
		$order = wc_get_order($order_id);
		
		$point      = $order->get_meta('cosmosfarm_point_pay_wc_apply_point', true);
		$prev_point = $order->get_meta('cosmosfarm_point_pay_wc_apply_point', true);
		
		if($prev_point){
			$point = $prev_point;
		}
		
		if($point):
		ob_start();
		?>
		<tr>
			<td class="label">포인트 사용</td>
			<td width="1%"></td>
			<td class="total">- <?php echo wc_price($point)?></td>
		</tr>
		<?php
		echo ob_get_clean();
		endif;
	}
	
	/**
	 * 환불 시 포인트를 반환한다.
	 */
	public function withdraw_point_after_order_refunded($order_id, $refund_id){
		$order            = wc_get_order($order_id);
		$apply_point      = $order->get_meta('cosmosfarm_point_pay_wc_apply_point', true);
		$earn_point       = $order->get_meta('cosmosfarm_point_pay_wc_earn_point', true);
		$user_id          = $order->get_customer_id();
		
		$is_applied_point      = $order->get_meta('cosmosfarm_point_pay_wc_is_applied_point', true);
		$prev_is_applied_point = $order->get_meta('cosmosfarm_pay_is_applied_point', true);
		
		if($prev_is_applied_point){
			$prev_is_applied_point = $prev_is_applied_point;
		}
		
		if($is_applied_point && $apply_point){
			mycred_add('pay_point', $user_id, $apply_point, "주문번호 '{$order_id}'번 주문, '".number_format($apply_point)."' 환불, 포인트 반환");
		}
		
		if($earn_point){
			mycred_add('pay_point', $user_id, '-'.$earn_point, "주문번호 '{$order_id}'번 주문, '".number_format($earn_point)."' 환불, 포인트 회수");
		}
	}
	
	/**
	 * 저장 시 포인트를 계산한다.
	 */
	public function calculate_point_when_save_order($order_id){
		if(!is_admin()){
			return;
		}
		
		if(!current_user_can('edit_page', $order_id)){
			return;
		}
		
		$post_type = isset($_POST['post_type']) ? $_POST['post_type'] : '';
		
		if($post_type == 'shop_order'){
			$order = new WC_Order($order_id);
			$point = $order->get_meta('cosmosfarm_point_pay_wc_apply_point', true);
			
			if($point){
				$price = $order->get_total();
				$caculated_price = (int)$price - (int)$point;
				$order->set_total($caculated_price);
			}
		}
	}
	
	/**
	 * recalculate 시 포인트를 계산한다.
	 */
	public function calculate_totals_when_recalculate($and_taxes, $order){
		$order_id   = $order->get_id();
		$point      = $order->get_meta('cosmosfarm_point_pay_wc_apply_point', true);
		$prev_point = $order->get_meta('cosmosfarm_point_pay_wc_apply_point', true);
		
		if($prev_point){
			$point = $prev_point;
		}
		
		if($point){
			$price = $order->get_total();
			$caculated_price = (int)$price - (int)$point;
			$order->set_total($caculated_price);
		}
	}
	
	/**
	 * 상품 데이터 탭에 포인트 탭을 추가한다.
	 */
	public function create_point_tabs($tabs){
		$tabs['cosmosfarm_point_pay_wc_simple'] = array(
			'label'    => '포인트 설정',
			'target'   => 'cosmosfarm_point_pay_wc',
			'class'    => 'hide_if_variable',
			'priority' => 60
		);
		return $tabs;
	}
	
	/**
	 * 상품별 포인트 탭의 내용을 표시한다.
	 */
	public function get_fields_to_simple(){
		$point = new Cosmosfarm_Point_Pay_WC_Point;
		
		echo '<div id="cosmosfarm_point_pay_wc" class="panel woocommerce_options_panel">';
		
		woocommerce_wp_select($point->get_earn_option());
		woocommerce_wp_text_input($point->get_earn_point());
		woocommerce_wp_select($point->get_use_option());
		
		echo '</div>';
		
		ob_start();
		?>
		<script>
		jQuery("#cosmosfarm_point_pay_wc_earn_option").on("change", function(){
			if(jQuery(this).val() == '2'){
				jQuery("p.cosmosfarm_point_pay_wc_earn_rate_point_field").removeClass("hidden");
			}
			else{
				jQuery("p.cosmosfarm_point_pay_wc_earn_rate_point_field").addClass("hidden");
			}
		});
		</script>
		<?php
		echo ob_get_clean();
	}
	
	/**
	 * 옵션별 포인트 탭의 내용을 표시한다.
	 */
	function get_fields_to_variations($loop, $variation_data, $variation){
		$point = new Cosmosfarm_Point_Pay_WC_Point;
		
		woocommerce_wp_select($point->get_earn_option($variation->ID));
		woocommerce_wp_text_input($point->get_earn_point($variation->ID));
		woocommerce_wp_select($point->get_use_option($variation->ID));
		
		ob_start();
		?>
		<script>
		jQuery("#cosmosfarm_point_pay_wc_earn_option_<?php echo $variation->ID?>").on("change", function(){
			if(jQuery(this).val() == '2'){
				jQuery("p.cosmosfarm_point_pay_wc_earn_rate_point_<?php echo $variation->ID?>_field").removeClass("hidden");
			}
			else{
				jQuery("p.cosmosfarm_point_pay_wc_earn_rate_point_<?php echo $variation->ID?>_field").addClass("hidden");
			}
		});
		</script>
		<?php
		echo ob_get_clean();
	}
	
	/**
	 * 상품 데이터 탭에 상품평 포인트 탭을 추가한다.
	 */
	public function create_review_point_tabs($tabs){
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		if($activation_earn_when_write_review){
			$tabs['cosmosfarm_point_pay_wc_review_point'] = array(
				'label'    => '상품평 포인트',
				'target'   => 'cosmosfarm_point_pay_wc_review_point',
				'priority' => 60
			);
		}
		
		return $tabs;
	}
	
	public function get_fields_to_review_point(){
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		if(!$activation_earn_when_write_review){
			return;
		}
		
		$point = new Cosmosfarm_Point_Pay_WC_Point;
		
		echo '<div id="cosmosfarm_point_pay_wc_review_point" class="panel woocommerce_options_panel">';
		
		woocommerce_wp_text_input($point->get_earn_point_when_write_review());
		
		echo '</div>';
	}
	
	/**
	 * 리뷰 작성 후 포인트를 적립한다.
	 */
	public function earn_write_review($id, $comment){
		$product_id = isset($comment->comment_post_ID) ? intval($comment->comment_post_ID) : 0;
		if(get_post_type($product_id) != 'product'){
			return;
		}
		
		extract(Cosmosfarm_Point_Pay_WC_Point::get_cosmosfarm_point_pay_wc_setting());
		
		if(!$activation_earn_when_write_review){
			return;
		}
		
		if(!function_exists('mycred_add') || !function_exists('mycred_get_users_balance')){
			return;
		}
		
		$user_id = isset($comment->user_id) ? intval($comment->user_id) : 0;
		if(!$user_id){
			return;
		}
		
		$product_point = get_post_meta($product_id, 'cosmosfarm_point_pay_wc_earn_point_when_write_review', true);
		$earn_point    = $product_point !== '' ? intval($product_point) : intval($earn_point_when_write_review);
		
		$text = apply_filters('cosmosfarm_point_pay_earn_point_when_write_review_ref', sprintf(__('상품평 작성 포인트 적립 (상품 #%d)'), $product_id));
		mycred_add('cosmosfarm point pay earn point when write review', $user_id, $earn_point, $text);
	}
	
	/**
	 * 새주문 추가 시 입력할 메타박스를 표시한다.
	 */
	public function add_meta_box($post_type, $post){
		if (!$post_type == 'shop_order' && $post_type == 'woocommerce_page_wc-orders') {
			return;
		}
		
		method_exists($post, 'get_status') ? $post_status = $post->get_status() : $post_status = $post->post_status;
		if ($post_status != 'auto-draft') {
			return;
		}
		
		add_meta_box('cosmosfarm_point_pay_wc_use_point', '포인트 입력', [$this, 'render_user_point'], [],'side', 'high');
	}
	
	public function render_user_point($post){
		method_exists($post, 'get_id') ? $post_id = $post->get_id() : $post_id = $post->ID;
		
		include COSMOSFARM_POINT_PAY_WC_DIR.'/admin/meta-box-user-point.php';
	}
}